# Outbid — website preview

A responsive, dark-mode frontend prototype for Outbid, a pay-to-rank business leaderboard.

## Run locally
Open `index.html` in a browser. No build step is required.

## Included in this preview
- Responsive landing page and leaderboard
- Demo business listings with clickable website links
- Submit-business modal
- Minimum bid set to $5 above the current #1 demo bid
- Local-only preview listing updates
- Demo visitor/revenue/business stats

## Important before taking real payments
This is a frontend prototype, not a production payment application. It does not collect money, persist listings, authenticate users, or display verified live analytics. The visitor and revenue figures are clearly demo values.

Production implementation should use:
- Next.js App Router and Tailwind CSS
- Supabase Postgres with row-level security and Google OAuth
- Stripe Checkout for one-time payments
- Stripe webhook signature verification as the source of truth for successful payments
- A database transaction/locking strategy so simultaneous bids cannot both claim the top spot
- Server-side bid validation, URL/logo validation, rate limiting, moderation and audit logs
- A server-side admin allowlist; never rely on hiding an admin link
- Stripe Dashboard / Stripe Connect as appropriate for payouts; do not store card details
- Privacy policy, terms, refund/cancellation policy, tax and payment-provider eligibility checks

## Suggested production rules
1. User submits a listing; keep it pending.
2. Server calculates the minimum bid from the current confirmed #1 bid.
3. Create Stripe Checkout Session server-side for that amount.
4. On a verified `checkout.session.completed` webhook, re-check the current #1 bid in a transaction.
5. If the minimum is no longer met, follow a defined policy (e.g. automatic refund) rather than silently placing an invalid bid.
6. Only then publish the listing and update the aggregate stats.

Do not deploy this preview as if it were already accepting live payments.
