const { createClient } = require("@supabase/supabase-js");

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  try {
    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const { data, error } = await supabase
      .from("businesses")
      .select("id,business_name,website_url,logo_url,bid_amount,created_at")
      .eq("status", "active")
      .order("bid_amount", { ascending: false })
      .order("created_at", { ascending: true })
      .limit(100);
    if (error) throw error;
    return res.status(200).json({ listings: data || [] });
  } catch (e) {
    console.error("leaderboard error", e.message);
    return res.status(503).json({ error: "Leaderboard database is not configured." });
  }
};
