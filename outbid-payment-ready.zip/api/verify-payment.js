const crypto = require("crypto");
const Razorpay = require("razorpay");
const { createClient } = require("@supabase/supabase-js");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature } = req.body || {};
    if (!orderId || !paymentId || !signature) return res.status(400).json({ error: "Missing payment verification fields." });
    const keySecret = process.env.RAZORPAY_KEY_SECRET;
    if (!keySecret || !process.env.RAZORPAY_KEY_ID || !process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      return res.status(503).json({ error: "Payment verification is not configured." });
    }
    const expected = crypto.createHmac("sha256", keySecret).update(`${orderId}|${paymentId}`).digest("hex");
    const a = Buffer.from(expected, "hex");
    const b = Buffer.from(String(signature), "hex");
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(400).json({ error: "Invalid payment signature." });
    }

    const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: keySecret });
    const [order, payment] = await Promise.all([
      razorpay.orders.fetch(orderId),
      razorpay.payments.fetch(paymentId)
    ]);
    if (payment.order_id !== orderId || payment.amount !== order.amount || payment.currency !== order.currency || Number(order.notes?.bid_amount) * 100 !== order.amount) {
      return res.status(400).json({ error: "Payment details do not match the order." });
    }
    if (payment.status !== "captured") {
      return res.status(409).json({ error: "Payment is not captured yet. Enable automatic capture in Razorpay or retry after capture." });
    }
    if (order.notes?.purpose !== "outbid_business_promotion") {
      return res.status(400).json({ error: "This order is not an Outbid promotion order." });
    }

    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    // Unique payment_id prevents the same payment being used to create multiple listings.
    const { data, error } = await supabase.from("businesses").insert({
      business_name: String(order.notes.business_name || "").slice(0, 80),
      website_url: order.notes.website_url,
      logo_url: order.notes.logo_url || null,
      bid_amount: Number(order.notes.bid_amount),
      payment_id: paymentId,
      razorpay_order_id: orderId,
      status: "active"
    }).select("id,business_name,bid_amount").single();
    if (error) {
      if (error.code === "23505") return res.status(200).json({ verified: true, alreadyProcessed: true });
      throw error;
    }
    return res.status(200).json({ verified: true, listing: data });
  } catch (e) {
    console.error("verify-payment error", e.message);
    return res.status(500).json({ error: "Could not verify payment. Check server logs and Razorpay payment status." });
  }
};
