const Razorpay = require("razorpay");
const { createClient } = require("@supabase/supabase-js");

function validUrl(value) {
  try {
    const u = new URL(value);
    return ["http:", "https:"].includes(u.protocol) ? u.href : null;
  } catch { return null; }
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { businessName, websiteUrl, logoUrl, bidAmount } = req.body || {};
    const name = String(businessName || "").trim();
    const website = validUrl(websiteUrl);
    const logo = logoUrl ? validUrl(logoUrl) : null;
    const bid = Number(bidAmount);
    if (!name || name.length > 80 || !website || (logoUrl && !logo) ||
        !Number.isSafeInteger(bid) || bid < 500 || bid > 10000000) {
      return res.status(400).json({ error: "Enter a valid business name, website and bid (minimum ₹500)." });
    }
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET ||
        !process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      return res.status(503).json({ error: "Payment system is not configured yet." });
    }
    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
    const { data: top, error: topError } = await supabase
      .from("businesses").select("bid_amount").eq("status", "active")
      .order("bid_amount", { ascending: false }).limit(1).maybeSingle();
    if (topError) throw topError;
    const minimum = top ? Number(top.bid_amount) + 100 : 500;
    if (bid < minimum) return res.status(400).json({ error: `Minimum bid is ₹${minimum.toLocaleString("en-IN")}. Refresh and try again.` });

    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET
    });
    const order = await razorpay.orders.create({
      amount: bid * 100,
      currency: "INR",
      receipt: `outbid_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      notes: {
        business_name: name,
        website_url: website,
        logo_url: logo || "",
        bid_amount: String(bid),
        purpose: "outbid_business_promotion"
      }
    });
    return res.status(200).json({ orderId: order.id, amount: order.amount, currency: order.currency });
  } catch (e) {
    console.error("create-order error", e.message);
    return res.status(500).json({ error: "Could not create a payment order. Check server configuration." });
  }
};
