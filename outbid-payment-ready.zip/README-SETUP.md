# Outbid — Razorpay setup starter

This package updates the supplied Outbid HTML and adds Vercel serverless API routes.
It is **not live until you finish all setup and Razorpay approves your business/payment use case**.

## What changed
- Replaced sample/demo leaderboard data with a server-loaded leaderboard.
- Added Razorpay Checkout flow.
- Server creates orders; browser never receives the Razorpay secret.
- Server verifies the checkout signature and confirms the payment is captured before publishing a listing.
- Supabase stores verified listings and blocks duplicate payment IDs.
- Uses INR pricing. International card acceptance and settlement must be enabled/approved by Razorpay; the code does not guarantee worldwide payment availability.

## Setup
1. Create a Razorpay account and complete business/KYC verification. Explain that the product sells paid business promotion / sponsored leaderboard placement and obtain written approval for this business model. Do not accept real payments before approval.
2. Create a Supabase project.
3. In Supabase > SQL Editor, run `supabase-schema.sql`.
4. In Vercel, connect/import this project as a repository (do not upload only `index.html`; the `api/` folder and `package.json` are required).
5. In Vercel > Project > Settings > Environment Variables, add:
   - `RAZORPAY_KEY_ID`
   - `RAZORPAY_KEY_SECRET`
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   Use Razorpay **test** keys first. Never expose the secret or Supabase service-role key in frontend code.
6. Redeploy after adding environment variables.
7. Test a payment using Razorpay test mode. Check that a listing appears only after captured payment.
8. Only after testing and approval, replace test keys with live keys and redeploy.

## Important production tasks still recommended
- Add privacy policy, terms of service, refund/cancellation policy, support email and business identity.
- Add webhook handling for reliable reconciliation if a customer closes the browser after payment.
- Add admin login and moderation controls before accepting public listings at scale.
- Confirm automatic capture is enabled in Razorpay.
- Review taxes, consumer protection, advertising disclosures, fraud handling and international payment eligibility with qualified professionals.
- Never share live secrets in chat. If a secret is ever exposed, rotate it immediately.

## Pricing behavior
- Currency is INR.
- First minimum bid is ₹500; each new bid must be at least ₹100 above the highest active verified bid.
- This is a simple paid-promotion model, not an auction escrow or guaranteed ad-performance service.
